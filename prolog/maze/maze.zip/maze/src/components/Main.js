import { useState } from 'react';
import React from 'react';


export default function Main(params) {
    
    const [content, setContent] = useState();
    const [data, setData] = useState();

    const fetchData = () => {

        let URL = "http://localhost:8085/?val=";
        var rad=document.getElementsByName('r1');
        for (var i=0;i<rad.length; i++) {
            if (rad[i].checked) {
                URL += rad[i].value;
            }
        }

        fetch(URL)
        .then(function(response) {
            // When the page is loaded convert it to text
            return response.text()
        })
        .then(function(html) {
            // Initialize the DOM parser
            var parser = new DOMParser();
    
            // Parse the text
            let doc = parser.parseFromString(html, "text/html");
    
            // You can now even select part of that html as you would in the regular DOM 
            // Example:
            // var docArticle = doc.querySelector('article').innerHTML;
            setContent(doc.getElementsByTagName('body')[0].innerHTML);
        })
        .catch(function(err) {  
            console.log('Failed to fetch page: ', err);  
        });
    }



    const getMaze = () => {
        fetchData();

        const data2 = content.split('[').slice(2);
        for (let i = 0; i < data2.length; i++) {
            data2[i] = data2[i].replaceAll(']', '');
            data2[i] = data2[i].replace(/\n/g, '');
        }
        console.log(data2);
        setData(data2);

        
    }




    return (
        <div className="main">
            
            <h1 className="h1">Добро пожаловать !!!</h1>
            
            <div className='top_block'>
                <button className='but' onClick={getMaze}>
                    Сгенерировать!
                </button>  
                

                <input className='rbut' name="r1" type="radio" value="10"/> 
                <p className='kek'>10x10</p>
                <input className='rbut' name="r1" type="radio" value="20"/>
                <p className='kek'>20x20</p>
                <input className='rbut' name="r1" type="radio" value="60"/>
                <p className='kek'>60x60</p>

            </div>
            
            <div className='bodyelems'>
            {data?.map((array) => {
                let elems = array.split(',');
                let contentElems = [];

                for (let i =0; i< elems.length; i++) {
                    if (elems[i] == "W") {
                        contentElems.push(<img className='elem' src='./brick.png'/>);
                    } else if (elems[i] == "T") {
                        contentElems.push(<img className='elem' src='./corona.webp'/>);
                    } else if (elems[i] == "O") {
                        contentElems.push(<img className='elem_air' src='./air.jpg'/>);
                    } else if (elems[i] == "V") {
                        contentElems.push(<img className='elem' src='./door.png'/>);
                    }
                }

                return (          
                        <div>
                            {contentElems}
                        </div>
                )
            }
               
            )}
            </div>

        </div>
        
    )
}
